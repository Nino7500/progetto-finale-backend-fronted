import React, { useState, useEffect } from 'react';
import { fetchWeatherData, saveWeatherData } from '../../Service/RESTService';
import { Table } from '../../Component/Table/Table';
import { useNavigate } from 'react-router-dom';
import { useContext } from 'react';
import { AuthContext } from '../../Component/Context/AuthContext/AuthContextProvider';

export function Home() {
  const [weatherData, setWeatherData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { handleLogout } = useContext(AuthContext);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await fetchWeatherData();
        setWeatherData(data);
        setLoading(false);
      } catch (error) {
        setError(error.message);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleSaveWeatherData = async () => {
    try {
      // Assicurati che i dati meteo siano disponibili prima di salvarli
      if (!weatherData) {
        throw new Error('Nessun dato meteo disponibile');
      }

      await saveWeatherData(weatherData);
      // Puoi fare qualcosa qui dopo aver salvato i dati, ad esempio visualizzare un messaggio di successo
    } catch (error) {
      console.error('Errore durante il salvataggio dei dati meteo:', error);
      // Gestisci l'errore, ad esempio mostrando un messaggio all'utente
    }
  };

  const logout = () => {
    handleLogout();
    navigate('/');
  };

  if (loading) {
    return <div>Caricamento...</div>;
  }

  if (error) {
    return <div>Si è verificato un errore: {error}</div>;
  }

  return (
    <div className='container mt-4 mb-4'>
      <button type="button" className="btn btn-danger" onClick={logout}>Logout</button>{' '}
      <button type="button" className="btn btn-success" onClick={handleSaveWeatherData}>Salva Dati Meteo</button>
      <Table weatherData={weatherData} />
    </div>
  );
}