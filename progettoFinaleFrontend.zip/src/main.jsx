import React from 'react'
import ReactDOM from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from "react-router-dom"
import { Login } from './Component/Login/Login';
import { Home } from './Pages/Home/Home';
import { Registrazione } from './Component/Registrazione/Registrazione';
import { AuthContextProvider } from './Component/Context/AuthContext/AuthContextProvider';
import "bootstrap/dist/css/bootstrap.css";
import "bootstrap/dist/js/bootstrap.bundle";
import { NotFound } from './Pages/NotFound/NotFound';

const router = createBrowserRouter([
  {
    element: <Login/>,
    path: ""
  },
  {
    element: <Registrazione/>,
    path: "/register"
  },
  {
    element: <NotFound/>,
    path: "*"
  },
  {
    element: (
      <AuthContextProvider>
        <Home/>
      </AuthContextProvider>
      ),
    path:"/home"
  }
]);

ReactDOM.createRoot(document.getElementById('root')).render(
  <RouterProvider router={router} />
)
