import React, { useState, useEffect } from 'react';
import { fetchWeatherData } from '../../Service/RESTService';

export function Table() {
  const [weatherData, setWeatherData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await fetchWeatherData();
        setWeatherData(data);
        setLoading(false);
      } catch (error) {
        setError(error.message);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return <div>Caricamento...</div>;
  }

  if (error) {
    return <div>Si è verificato un errore: {error}</div>;
  }

  // Funzione ricorsiva per costruire la tabella
  const buildTable = (obj, parentKey = '') => {
    return Object.keys(obj).map((key) => {
      const newKey = parentKey ? `${parentKey}.${key}` : key;
      const value = obj[key];

      if (typeof value === 'object') {
        return buildTable(value, newKey);
      } else {
        return (
          <tr key={newKey}>
            <td className="fw-bold">{newKey}</td>
            <td>{value}</td>
          </tr>
        );
      }
    });
  };

  return (
    <div>
      <h2>Dati Meteo</h2>
      <table className="table table-striped table-bordered">
        <thead>
          <tr>
            <th>Chiave</th>
            <th>Valore</th>
          </tr>
        </thead>
        <tbody>
          {buildTable(weatherData)}
        </tbody>
      </table>
    </div>
  );
}