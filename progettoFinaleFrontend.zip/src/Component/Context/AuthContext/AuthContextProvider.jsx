import { createContext, useState, useEffect } from 'react';
import Cookies from 'js-cookie';

export const AuthContext = createContext();

export const AuthContextProvider = ({ children }) => {
    const [isLogged, setIsLogged] = useState(false);
    const [user, setUser] = useState({
        nome: "",
        cognome: "",
        email: "",
    });
    const [token, setToken] = useState(Cookies.get('token') || '');

    const handleLogin = (newUser, newToken) => {
        setIsLogged(true);
        setUser(newUser);
        setToken(newToken);
        Cookies.set('token', newToken);
    };

    const handleLogout = () => {
        setIsLogged(false);
        setUser({
            nome: "",
            cognome: "",
            email: "",
        });
        setToken('');
        Cookies.remove('token');
    };

    useEffect(() => {
        if (!token) {
            handleLogout();
        }
    }, []);

    return (
        <AuthContext.Provider value={{ isLogged, user, token, handleLogin, handleLogout }}>
            {children}
        </AuthContext.Provider>
    );
};