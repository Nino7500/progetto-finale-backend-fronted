import { login } from "../../Service/RESTService";
import { useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import Cookies from "js-cookie";
import { jwtDecode } from "jwt-decode";




export function Login() {
    const [formData, setFormData] = useState({
      email: "",
      password: "",
    });
  
    const [errorFlag, setErrorFlag] = useState(false);
    const navigate = useNavigate();
  
    const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData({ ...formData, [name]: value });
    };
  
    const handleSubmit = async (e) => {
      e.preventDefault();
  
      try {
        const response = await login(formData.email, formData.password);
        if (response.ok) {
          const data = await response.json();
          if (data.token) {
            console.log("Login avvenuto con successo!");
            console.log(response);
  
            const token = data.token;
            console.log(token);
            Cookies.set("token", token);
  
            const decodedToken = jwtDecode(token);
            console.log(decodedToken);
  
            navigate("/home");
          } else {
            console.log("Credenziali non valide. Riprova.");
            setErrorFlag(true);
          }
        }
      } catch (error) {
        console.error("Errore durante il login:", error);
        setErrorFlag(true);
      }
    };
    return (
        <div className="container mt-5">
            <div className="row justify-content-center">
                <div className="col-md-6">
                    <div className="card ${styles.color">
                        <div className="card-body">
                            <h2 className="card-title mb-4">Login</h2>
                            <form onSubmit={handleSubmit}>
                                <div className="mb-3">
                                    <input
                                        type="email"
                                        name="email"
                                        placeholder="Email"
                                        value={formData.email}
                                        onChange={handleChange}
                                        className="form-control"
                                        required
                                    />
                                </div>
                                <div className="mb-3">
                                    <input
                                        type="password"
                                        name="password"
                                        placeholder="Password"
                                        value={formData.password}
                                        onChange={handleChange}
                                        className="form-control"
                                        required
                                    />
                                </div>
                                <button type="submit" className="btn btn-primary">
                                    Login
                                </button>
                            </form>
                            {/* Sezione per la registrazione */}
                            <div className="mt-3">
                                <p>Non sei ancora registrato? Clicca qui!</p>
                                <NavLink to="/register" className="btn btn-link">Registrati</NavLink>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
  }
  