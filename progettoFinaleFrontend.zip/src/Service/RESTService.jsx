import { jwtDecode } from "jwt-decode";
import Cookies from "js-cookie";

export async function register(userData) {
    try {
      const response = await fetch("http://localhost:8080/api/utenti/registrazione", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(userData),
      });
  
      if (!response.ok) {
        throw new Error("Errore durante la registrazione");
      }

      window.location.href = "/";
  
      const data = await response.json();
      return data;
    } catch (error) {
      console.error("Errore durante la registrazione:", error.message);
    
      alert("Si è verificato un errore durante la registrazione. Riprova più tardi.");
      throw error;
    }
  }


export async function login(email, password) {
    try {
      const response = await fetch("http://localhost:8080/api/utenti/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      });
  
      return response;
    } catch (error) {
      throw error;
    }
  }

  export async function logout(token) {
    try {
      const response = await fetch("http://localhost:8080/api/utenti/logout", {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`
        },
      });
  
      if (response.ok) {
        console.log(response);
        return true; 
      } else {
        throw new Error("Errore durante il logout");
      }
    } catch (error) {
      throw error;
    }
  }

  export async function fetchWeatherData() {
    try {
      const API_KEY = '374a9cd52a2c43b8aef81716241405';
      const CITY = 'Palermo';
      const API_URL = `http://api.weatherapi.com/v1/current.json?key=${API_KEY}&q=${CITY}&aqi=no`;
      
      const response = await fetch(API_URL);
      if (!response.ok) {
        throw new Error('Errore nella richiesta dei dati meteo');
      }
      
      const weatherData = await response.json();
      return weatherData;
    } catch (error) {
      throw error;
    }
  }

  
export async function saveWeatherData(weatherData) {
    try {
        const formattedData = {};
  
        // Estrai solo le chiavi e i valori dai dati meteo
        Object.keys(weatherData).forEach((key) => {
            const value = weatherData[key];
  
            // Controlla se il valore è un oggetto JSON
            if (typeof value !== 'object') {
                formattedData[key] = value;
            } else {
                // Se il valore è un oggetto JSON, estrai solo le chiavi e i valori
                Object.keys(value).forEach((nestedKey) => {
                    formattedData[nestedKey] = value[nestedKey];
                });
            }
        });
        
        // Ottieni il token dal cookie
        const token = Cookies.get('token');
        console.log("toooookjen"+token)
        
        // Decodifica il token per ottenere le informazioni sull'utente
        const decodedToken = jwtDecode(token);
        
        const tokenString = JSON.stringify(decodedToken)
        console.log("deeeeeeet  "+tokenString)
        // Estrai l'ID dell'utente dalle informazioni decodificate
        const {id} = decodedToken;

        console.log("iiiiiidddddd"+id)
        
        // Aggiungi l'ID dell'utente al JSON
        formattedData['utente_id'] = id;

        console.log(formattedData)
  
        const response = await fetch("http://localhost:8080/api/meteo/salva", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(formattedData)
        });
  
        if (!response.ok) {
            throw new Error("Errore durante il salvataggio dei dati meteo");
        }
  
        const savedData = await response.json();
        return savedData;
    } catch (error) {
        throw error;
    }
}